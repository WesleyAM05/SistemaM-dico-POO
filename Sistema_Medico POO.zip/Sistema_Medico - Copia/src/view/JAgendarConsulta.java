package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.TextArea;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;

import DAO.DBConnection; // Importar a classe DBConnection

public class JAgendarConsulta extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_2;
	private JFormattedTextField formattedTextField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JAgendarConsulta frame = new JAgendarConsulta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public JAgendarConsulta() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Tela Agendar Consulta - GWM");
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_1.setBackground(new Color(178, 187, 182));
		contentPane_1.setBounds(0, 0, 784, 561);
		contentPane.add(contentPane_1);

		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBackground(new Color(21, 23, 43));
		panel_4.setBounds(0, 0, 784, 77);
		contentPane_1.add(panel_4);

		JLabel lblConsultasCriar = new JLabel("Consultas - Agendar");
		lblConsultasCriar.setForeground(Color.WHITE);
		lblConsultasCriar.setFont(new Font("Segoe UI", Font.BOLD, 30));
		lblConsultasCriar.setBounds(471, 14, 285, 41);
		panel_4.add(lblConsultasCriar);

		JLabel lblNewLabel = new JLabel("Clínica GWM");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 19));
		lblNewLabel.setBounds(97, 26, 138, 26);
		panel_4.add(lblNewLabel);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(0, 0, 80, 80);
		panel_4.add(lblNewLabel_3);
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\pngtree-medical-health-logo-imag.png"));

		textField = new JTextField();
		textField.setBounds(45, 148, 672, 38);
		contentPane_1.add(textField);
		textField.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(280, 224, 154, 38);
		contentPane_1.add(textField_2);

		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 14));
		comboBox.setModel(new DefaultComboBoxModel<>(new String[] { "Selecione", "Cirurgião", "Dentista" }));
		comboBox.setBounds(563, 222, 154, 38);
		contentPane_1.add(comboBox);

		TextArea textArea = new TextArea();
		textArea.setBounds(45, 305, 672, 176);
		contentPane_1.add(textArea);

		JLabel lblNewLabel_1 = new JLabel("Nome Completo do Paciente");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(45, 123, 196, 14);
		contentPane_1.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Data");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(45, 199, 46, 14);
		contentPane_1.add(lblNewLabel_2);

		JLabel lblNewLabel_4 = new JLabel("Horário");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(280, 199, 63, 14);
		contentPane_1.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Tipo de Consulta");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(563, 197, 127, 14);
		contentPane_1.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("Observações:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(45, 283, 93, 14);
		contentPane_1.add(lblNewLabel_6);

		JButton btnNewButton_2 = new JButton("Salvar");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nomePaciente = textField.getText();
				String dataConsulta = textField_2.getText();
				String horaConsulta = formattedTextField.getText();
				String observacoes = textArea.getText(); // Captura as observações
				String tipoConsulta = (String) comboBox.getSelectedItem(); // Captura o tipo de consulta

				int pacienteId = DBConnection.findPacienteByName(nomePaciente);

				if (pacienteId != -1) {
					if (DBConnection.saveConsulta(pacienteId, dataConsulta, horaConsulta, observacoes, tipoConsulta)) {
						JOptionPane.showMessageDialog(null, "Consulta salva com sucesso!", "Sucesso",
								JOptionPane.INFORMATION_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null, "Erro ao salvar a consulta.", "Erro",
								JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, "Paciente não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_2.setForeground(new Color(0, 0, 0));
		btnNewButton_2.setBackground(new Color(194, 80, 70));
		btnNewButton_2.setBounds(222, 504, 105, 38);
		contentPane_1.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("Cancelar");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_2.setText("");
				formattedTextField.setText("");
				comboBox.setSelectedIndex(0); // Se precisa redefinir ComboBox
				textArea.setText("");
				JOptionPane.showMessageDialog(null, "Consulta cancelada.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_3.setBackground(new Color(85, 121, 143));
		btnNewButton_3.setBounds(425, 504, 105, 38);
		contentPane_1.add(btnNewButton_3);

		formattedTextField = new JFormattedTextField();
		formattedTextField.setHorizontalAlignment(SwingConstants.LEFT);
		formattedTextField.setFont(new Font("Tahoma", Font.PLAIN, 11));
		formattedTextField.setBounds(45, 222, 154, 38);
		contentPane_1.add(formattedTextField);
	}
}
