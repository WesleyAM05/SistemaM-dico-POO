package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class JHistoricoConsulta extends JFrame {
	private DefaultTableModel model;
	private JTable tabela;
	private JTextField pesquisaField;

	public JHistoricoConsulta() {
		setTitle("Histórico de Consultas");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		String[] colunas = { "ID", "Data", "Hora", "Tipo" };
		model = new DefaultTableModel(colunas, 0);
		tabela = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(tabela);

		pesquisaField = new JTextField(30);
		JButton pesquisarButton = new JButton("Pesquisar");

		pesquisarButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String texto = pesquisaField.getText();
				filtrarDados(texto);
			}
		});

		JPanel searchPanel = new JPanel();
		searchPanel.add(pesquisaField);
		searchPanel.add(pesquisarButton);

		getContentPane().add(scrollPane, BorderLayout.CENTER);
		getContentPane().add(searchPanel, BorderLayout.NORTH);

		carregarDados("");
	}

	private void carregarDados(String filtro) {
		String url = "jdbc:mysql://localhost:3306/sistemamedico";
		String usuario = "root";
		String senha = "root";

		try (Connection conn = DriverManager.getConnection(url, usuario, senha)) {
			String query = "SELECT id, data_consulta, hora_consulta, tipo_consulta FROM consultas";

			if (!filtro.isEmpty()) {
				query += " WHERE nome_paciente LIKE ?";
			}

			try (PreparedStatement stmt = conn.prepareStatement(query)) {
				if (!filtro.isEmpty()) {
					stmt.setString(1, "%" + filtro + "%");
				}

				try (ResultSet rs = stmt.executeQuery()) {
					model.setRowCount(0);

					while (rs.next()) {
						int id = rs.getInt("id");
						String data = rs.getString("data_consulta");
						String hora = rs.getString("hora_consulta");
						String tipo = rs.getString("tipo_consulta");
						model.addRow(new Object[] { id, data, hora, tipo });
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void filtrarDados(String filtro) {
		carregarDados(filtro);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			JHistoricoConsulta frame = new JHistoricoConsulta();
			frame.setVisible(true);
		});
	}
}
