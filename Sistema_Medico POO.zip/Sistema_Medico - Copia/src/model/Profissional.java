package model;

public class Profissional {

	    private int matricula;
	    private String cep;
	    private String nome;
	    private String genero;
	    private String email;
	    private int profissionalizacao;
	    private int telefone;
	    private String dataNasc;
	    private int idade;
	    private String cpf;
	    private String rg;
	    
	    
		public Profissional(int matricula, String cep, String nome, String genero, String email, int profissionalizacao,
				int telefone, String dataNasc, int idade, String cpf, String rg) {
			super();
			this.matricula = matricula;
			this.cep = cep;
			this.nome = nome;
			this.genero = genero;
			this.email = email;
			this.profissionalizacao = profissionalizacao;
			this.telefone = telefone;
			this.dataNasc = dataNasc;
			this.idade = idade;
			this.cpf = cpf;
			this.rg = rg;
		}
		
		public int getMatricula() {
			return matricula;
		}


		public void setMatricula(int matricula) {
			this.matricula = matricula;
		}


		public String getCep() {
			return cep;
		}


		public void setCep(String cep) {
			this.cep = cep;
		}


		public String getNome() {
			return nome;
		}


		public void setNome(String nome) {
			this.nome = nome;
		}


		public String getGenero() {
			return genero;
		}


		public void setGenero(String genero) {
			this.genero = genero;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public int getProfissionalizacao() {
			return profissionalizacao;
		}


		public void setProfissionalizacao(int profissionalizacao) {
			this.profissionalizacao = profissionalizacao;
		}


		public int getTelefone() {
			return telefone;
		}


		public void setTelefone(int telefone) {
			this.telefone = telefone;
		}


		public String getDataNasc() {
			return dataNasc;
		}


		public void setDataNasc(String dataNasc) {
			this.dataNasc = dataNasc;
		}


		public int getIdade() {
			return idade;
		}


		public void setIdade(int idade) {
			this.idade = idade;
		}


		public String getCpf() {
			return cpf;
		}


		public void setCpf(String cpf) {
			this.cpf = cpf;
		}


		public String getRg() {
			return rg;
		}


		public void setRg(String rg) {
			this.rg = rg;
		}
	    
}