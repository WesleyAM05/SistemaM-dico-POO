package model;

public class Consulta {
	private int numero;
	private String data;
	private String hora;
	private String tipo;
	
	public Consulta(int numero, String data, String hora, String tipo) {
		super();
		this.numero = numero;
		this.data = data;
		this.hora = hora;
		this.tipo = tipo;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	

}
