/**
 * 
 */
/**
 * 
 */
module Sistema_Medico {
	requires java.desktop;
	requires java.sql;
}