package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Panel;
import java.awt.GridLayout;
import java.awt.Cursor;
import javax.swing.JMenuBar;
import javax.swing.UIManager;

public class JPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JPrincipal frame = new JPrincipal();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Tela Home - GWM");
		setBounds(100, 100, 1057, 666);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(178, 187, 182));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color(85, 132, 91));
		panel.setBounds(143, 132, 324, 194);
		contentPane.add(panel);
		panel.setLayout(null);

		JPanel panel_5 = new JPanel();
		panel_5.setBounds(0, 134, 324, 60);
		panel.add(panel_5);
		panel_5.setLayout(null);

		JButton btnNewButton_4 = new JButton("Histórico");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JHistoricoConsulta h = new JHistoricoConsulta();
				this.dispose();
				h.setLocationRelativeTo(null);
				h.setVisible(true);
			}

			private void dispose() {
				// TODO Auto-generated method stub

			}
		});
		btnNewButton_4.setBounds(126, 20, 89, 23);
		panel_5.add(btnNewButton_4);
		btnNewButton_4.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewButton_4.setBorder(null);
		btnNewButton_4.setBackground(new Color(240, 240, 240));

		JButton btnNewButton_3 = new JButton("Agendar");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JAgendarConsulta l = new JAgendarConsulta();
				this.dispose();
				l.setLocationRelativeTo(null);
				l.setVisible(true);
			}

			private void dispose() {
				// TODO Auto-generated method stub

			}
		});
		btnNewButton_3.setBounds(10, 20, 106, 23);
		panel_5.add(btnNewButton_3);
		btnNewButton_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewButton_3.setBorder(null);
		btnNewButton_3.setBackground(new Color(240, 240, 240));

		JLabel lblNewLabel_1 = new JLabel("Consultas");
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(137, 52, 134, 27);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBackground(new Color(218, 187, 15));
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\laptop-medico (1).png"));
		lblNewLabel_2.setBounds(67, 32, 60, 60);
		panel.add(lblNewLabel_2);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(85, 121, 143));
		panel_1.setBounds(577, 132, 324, 194);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JPanel panel_5_1 = new JPanel();
		panel_5_1.setBounds(0, 134, 324, 60);
		panel_5_1.setLayout(null);
		panel_1.add(panel_5_1);

		JButton btnNewButton_2_1 = new JButton("Cadastrar");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JCadastrarPaciente cp = new JCadastrarPaciente();
				this.dispose();
				cp.setLocationRelativeTo(null);
				cp.setVisible(true);
			}

			private void dispose() {
				// TODO Auto-generated method stub

			}
		});
		btnNewButton_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewButton_2_1.setBorder(null);
		btnNewButton_2_1.setBackground(new Color(240, 240, 240));
		btnNewButton_2_1.setBounds(10, 18, 89, 23);
		panel_5_1.add(btnNewButton_2_1);

		JButton btnNewButton_3_1 = new JButton("Listar");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JListaPacientes lp = new JListaPacientes();
				this.dispose();
				lp.setLocationRelativeTo(null);
				lp.setVisible(true);
			}

			private void dispose() {
				// TODO Auto-generated method stub

			}
		});
		btnNewButton_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewButton_3_1.setBorder(null);
		btnNewButton_3_1.setBackground(new Color(240, 240, 240));
		btnNewButton_3_1.setBounds(109, 18, 106, 23);
		panel_5_1.add(btnNewButton_3_1);

		JLabel lblNewLabel_2_1 = new JLabel("");
		lblNewLabel_2_1.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\usuarios-medicos (1).png"));
		lblNewLabel_2_1.setBackground(new Color(218, 187, 15));
		lblNewLabel_2_1.setBounds(70, 37, 60, 60);
		panel_1.add(lblNewLabel_2_1);

		JLabel lblNewLabel_1_1 = new JLabel("Pacientes");
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(140, 57, 134, 27);
		panel_1.add(lblNewLabel_1_1);

		JPanel panel_2 = new JPanel();
		panel_2.setBorder(null);
		panel_2.setBackground(new Color(218, 187, 15));
		panel_2.setBounds(143, 371, 324, 194);
		contentPane.add(panel_2);
		panel_2.setLayout(null);

		JPanel panel_5_2 = new JPanel();
		panel_5_2.setBounds(0, 134, 324, 60);
		panel_2.add(panel_5_2);
		panel_5_2.setLayout(null);

		JButton btnNewButton_3_2 = new JButton("Documentos");
		btnNewButton_3_2.setBounds(107, 19, 106, 23);
		btnNewButton_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewButton_3_2.setBorder(null);
		btnNewButton_3_2.setBackground(new Color(240, 240, 240));
		panel_5_2.add(btnNewButton_3_2);

		JLabel lblNewLabel_2_2 = new JLabel("");
		lblNewLabel_2_2.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\arquivo-medico-alt (1).png"));
		lblNewLabel_2_2.setBackground(new Color(218, 187, 15));
		lblNewLabel_2_2.setBounds(65, 31, 60, 60);
		panel_2.add(lblNewLabel_2_2);

		JLabel lblNewLabel_1_2 = new JLabel("Relatórios");
		lblNewLabel_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblNewLabel_1_2.setBounds(135, 51, 134, 27);
		panel_2.add(lblNewLabel_1_2);

		JPanel panel_3 = new JPanel();
		panel_3.setBorder(null);
		panel_3.setBackground(new Color(194, 80, 70));
		panel_3.setBounds(577, 371, 324, 194);
		contentPane.add(panel_3);
		panel_3.setLayout(null);

		JPanel panel_5_1_1 = new JPanel();
		panel_5_1_1.setLayout(null);
		panel_5_1_1.setBounds(0, 134, 324, 60);
		panel_3.add(panel_5_1_1);

		JButton btnNewButton_2_1_1 = new JButton("Cadastrar");
		btnNewButton_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JCadastrarMedico cd = new JCadastrarMedico();
				this.dispose();
				cd.setLocationRelativeTo(null);
				cd.setVisible(true);

			}

			private void dispose() {
				// TODO Auto-generated method stub

			}
		});
		btnNewButton_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewButton_2_1_1.setBorder(null);
		btnNewButton_2_1_1.setBackground(new Color(240, 240, 240));
		btnNewButton_2_1_1.setBounds(10, 18, 89, 23);
		panel_5_1_1.add(btnNewButton_2_1_1);

		JButton btnNewButton_4_1_1 = new JButton("Histórico");
		btnNewButton_4_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewButton_4_1_1.setBorder(null);
		btnNewButton_4_1_1.setBackground(new Color(240, 240, 240));
		btnNewButton_4_1_1.setBounds(225, 18, 89, 23);
		panel_5_1_1.add(btnNewButton_4_1_1);

		JButton btnNewButton_3_1_1 = new JButton("Editar");
		btnNewButton_3_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewButton_3_1_1.setBorder(null);
		btnNewButton_3_1_1.setBackground(new Color(240, 240, 240));
		btnNewButton_3_1_1.setBounds(109, 18, 106, 23);
		panel_5_1_1.add(btnNewButton_3_1_1);

		JLabel lblNewLabel_2_1_1 = new JLabel("");
		lblNewLabel_2_1_1.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\usuario-md (1).png"));
		lblNewLabel_2_1_1.setBackground(new Color(218, 187, 15));
		lblNewLabel_2_1_1.setBounds(61, 34, 60, 60);
		panel_3.add(lblNewLabel_2_1_1);

		JLabel lblNewLabel_1_1_1 = new JLabel("Médicos");
		lblNewLabel_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblNewLabel_1_1_1.setBounds(131, 54, 134, 27);
		panel_3.add(lblNewLabel_1_1_1);

		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(21, 23, 43));
		panel_4.setBounds(0, 0, 1041, 77);
		contentPane.add(panel_4);
		panel_4.setLayout(null);

		JLabel lblNewLabel = new JLabel("Clínica GWM");
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 19));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(97, 26, 138, 26);
		panel_4.add(lblNewLabel);

		JButton btnNewButton = new JButton("");
		btnNewButton.setBackground(null);
		btnNewButton.setBorder(null);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\do-utilizador (1).png"));
		btnNewButton.setBounds(907, 23, 54, 40);
		panel_4.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\poder (1).png"));
		btnNewButton_1.setBounds(971, 23, 54, 40);
		btnNewButton_1.setBackground(null);
		btnNewButton_1.setBorder(null);
		panel_4.add(btnNewButton_1);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(7, 0, 80, 80);
		panel_4.add(lblNewLabel_3);
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\pngtree-medical-health-logo-imag.png"));

		JLabel lblHome = new JLabel("HOME");
		lblHome.setForeground(Color.WHITE);
		lblHome.setFont(new Font("Segoe UI", Font.BOLD, 30));
		lblHome.setBounds(474, 21, 91, 26);
		panel_4.add(lblHome);
	}
}
