package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;

import DAO.DBConnection; // Certifique-se de importar a classe DBConnection
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.awt.event.ActionEvent;

public class JCadastrarMedico extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNomeCompleto;
	private JTextField txtDataNasc;
	private JTextField txtCPF;
	private JTextField txtEmail;
	private JTextField txtTelefone;
	private JTextField txtCEP;
	private JTextField txtLogradouro;
	private JTextField txtBairro;
	private JTextField txtCidade;
	private JTextField txtUF;
	private JTextField txtProfissionalizacao;
	private JTextField txtMatricula;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JCadastrarMedico frame = new JCadastrarMedico();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public JCadastrarMedico() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 784, 561);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBackground(new Color(21, 23, 43));
		panel_4.setBounds(0, 0, 768, 77);
		contentPane.add(panel_4);

		JLabel lblMedicosCadastrar = new JLabel("Médicos - Cadastrar");
		lblMedicosCadastrar.setForeground(Color.WHITE);
		lblMedicosCadastrar.setFont(new Font("Segoe UI", Font.BOLD, 30));
		lblMedicosCadastrar.setBounds(446, 14, 312, 41);
		panel_4.add(lblMedicosCadastrar);

		JLabel lblNewLabel = new JLabel("Clínica GWM");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 19));
		lblNewLabel.setBounds(97, 26, 138, 26);
		panel_4.add(lblNewLabel);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\pngtree-medical-health-logo-imag.png"));
		lblNewLabel_3.setBounds(0, 0, 80, 80);
		panel_4.add(lblNewLabel_3);

		txtNomeCompleto = new JTextField();
		txtNomeCompleto.setBounds(163, 107, 441, 33);
		contentPane.add(txtNomeCompleto);
		txtNomeCompleto.setColumns(10);

		try {
			MaskFormatter mfData = new MaskFormatter("##/##/####");
			mfData.setPlaceholderCharacter('_');
			txtDataNasc = new JFormattedTextField(mfData);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		txtDataNasc.setBounds(163, 171, 111, 32);
		contentPane.add(txtDataNasc);
		txtDataNasc.setColumns(10);

		try {
			MaskFormatter mfCpf = new MaskFormatter("###.###.###-##");
			mfCpf.setPlaceholderCharacter('_');
			txtCPF = new JFormattedTextField(mfCpf);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		txtCPF.setBounds(320, 171, 111, 32);
		contentPane.add(txtCPF);
		txtCPF.setColumns(10);

		JComboBox<String> comboBoxGenero = new JComboBox<>();
		comboBoxGenero.setFont(new Font("Tahoma", Font.PLAIN, 14));
		comboBoxGenero
				.setModel(new DefaultComboBoxModel<>(new String[] { "Selecione", "Masculino", "Feminino", "Outro" }));
		comboBoxGenero.setBounds(493, 171, 111, 32);
		contentPane.add(comboBoxGenero);

		txtEmail = new JTextField();
		txtEmail.setBounds(163, 235, 138, 32);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);

		try {
			MaskFormatter mfTel = new MaskFormatter("(##) #####-####");
			mfTel.setPlaceholderCharacter('_');
			txtTelefone = new JFormattedTextField(mfTel);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		txtTelefone.setBounds(330, 233, 112, 32);
		contentPane.add(txtTelefone);
		txtTelefone.setColumns(10);

		try {
			MaskFormatter mfCep = new MaskFormatter("#####-###");
			mfCep.setPlaceholderCharacter('_');
			txtCEP = new JFormattedTextField(mfCep);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		txtCEP.setBounds(319, 297, 138, 32);
		contentPane.add(txtCEP);
		txtCEP.setColumns(10);

		txtLogradouro = new JTextField();
		txtLogradouro.setBounds(482, 299, 122, 32);
		contentPane.add(txtLogradouro);
		txtLogradouro.setColumns(10);

		txtBairro = new JTextField();
		txtBairro.setBounds(163, 361, 138, 32);
		contentPane.add(txtBairro);
		txtBairro.setColumns(10);

		txtCidade = new JTextField();
		txtCidade.setBounds(340, 361, 130, 32);
		contentPane.add(txtCidade);
		txtCidade.setColumns(10);

		txtUF = new JTextField();
		txtUF.setBounds(500, 361, 104, 32);
		contentPane.add(txtUF);
		txtUF.setColumns(10);

		txtProfissionalizacao = new JTextField();
		txtProfissionalizacao.setColumns(10);
		txtProfissionalizacao.setBounds(492, 235, 112, 32);
		contentPane.add(txtProfissionalizacao);

		txtMatricula = new JTextField();
		txtMatricula.setColumns(10);
		txtMatricula.setBounds(163, 297, 138, 32);
		contentPane.add(txtMatricula);

		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnCadastrar.setBounds(263, 443, 123, 33);
		btnCadastrar.setBackground(new Color(85, 121, 143));
		contentPane.add(btnCadastrar);

		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnCancelar.setBackground(new Color(194, 80, 70));
		btnCancelar.setBounds(430, 445, 97, 33);
		contentPane.add(btnCancelar);

		JLabel lblNomeCompleto = new JLabel("Nome Completo");
		lblNomeCompleto.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNomeCompleto.setBounds(163, 88, 104, 14);
		contentPane.add(lblNomeCompleto);

		JLabel lblDataNascimento = new JLabel("Data Nascimento");
		lblDataNascimento.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDataNascimento.setBounds(163, 151, 104, 14);
		contentPane.add(lblDataNascimento);

		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCpf.setBounds(320, 151, 46, 14);
		contentPane.add(lblCpf);

		JLabel lblGenero = new JLabel("Gênero");
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblGenero.setBounds(493, 151, 46, 14);
		contentPane.add(lblGenero);

		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblEmail.setBounds(163, 214, 46, 14);
		contentPane.add(lblEmail);

		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTelefone.setBounds(330, 214, 112, 14);
		contentPane.add(lblTelefone);

		JLabel lblCep = new JLabel("CEP");
		lblCep.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCep.setBounds(319, 276, 46, 14);
		contentPane.add(lblCep);

		JLabel lblLogradouro = new JLabel("Logradouro");
		lblLogradouro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblLogradouro.setBounds(482, 278, 97, 16);
		contentPane.add(lblLogradouro);

		JLabel lblBairro = new JLabel("Bairro");
		lblBairro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblBairro.setBounds(163, 342, 46, 14);
		contentPane.add(lblBairro);

		JLabel lblCidade = new JLabel("Cidade");
		lblCidade.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCidade.setBounds(340, 342, 46, 14);
		contentPane.add(lblCidade);

		JLabel lblUf = new JLabel("UF");
		lblUf.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblUf.setBounds(500, 342, 46, 14);
		contentPane.add(lblUf);

		JLabel lblProfissionalizacao = new JLabel("Profissionalização");
		lblProfissionalizacao.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblProfissionalizacao.setBounds(492, 216, 112, 14);
		contentPane.add(lblProfissionalizacao);

		JLabel lblMatricula = new JLabel("Mátricula");
		lblMatricula.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblMatricula.setBounds(163, 276, 83, 14);
		contentPane.add(lblMatricula);

		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = txtNomeCompleto.getText();
				String dataNasc = txtDataNasc.getText();
				String cpf = txtCPF.getText();
				String genero = comboBoxGenero.getSelectedItem().toString();
				String email = txtEmail.getText();
				String telefone = txtTelefone.getText();
				String cep = txtCEP.getText();
				String logradouro = txtLogradouro.getText();
				String bairro = txtBairro.getText();
				String cidade = txtCidade.getText();
				String uf = txtUF.getText();
				String profissionalizacao = txtProfissionalizacao.getText();
				String matricula = txtMatricula.getText();

				if (nome.isEmpty() || dataNasc.isEmpty() || cpf.isEmpty() || genero.equals("Selecione")
						|| email.isEmpty() || telefone.isEmpty() || cep.isEmpty() || logradouro.isEmpty()
						|| bairro.isEmpty() || cidade.isEmpty() || uf.isEmpty() || profissionalizacao.isEmpty()
						|| matricula.isEmpty()) {

					JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.", "Aviso",
							JOptionPane.WARNING_MESSAGE);

				} else {
					try {
						boolean isSaved = DBConnection.savePatient1(nome, dataNasc, cpf, genero, email, telefone, cep,
								logradouro, bairro, cidade, uf, profissionalizacao, matricula);
						if (isSaved) {
							JOptionPane.showMessageDialog(null, "Medico cadastrado com sucesso!", "Sucesso",
									JOptionPane.INFORMATION_MESSAGE);
							txtNomeCompleto.setText("");
							txtDataNasc.setText("");
							txtCPF.setText("");
							comboBoxGenero.setSelectedIndex(0);
							txtEmail.setText("");
							txtTelefone.setText("");
							txtCEP.setText("");
							txtLogradouro.setText("");
							txtBairro.setText("");
							txtCidade.setText("");
							txtUF.setText("");
							txtProfissionalizacao.setText("");
							txtMatricula.setText("");
						} else {
							JOptionPane.showMessageDialog(null, "Erro ao cadastrar medico.", "Erro",
									JOptionPane.ERROR_MESSAGE);
						}
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "Erro: " + ex.getMessage(), "Erro",
								JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});

		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
}
