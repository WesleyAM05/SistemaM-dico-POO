package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DAO.DBConnection;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.AbstractButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.text.MaskFormatter;
import java.awt.TextArea;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;

public class JAgendarConsulta extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JFormattedTextField textField_2;
	private JFormattedTextField formattedTextField;
	private JComboBox<String> comboBoxProfissionalizacoes;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JAgendarConsulta frame = new JAgendarConsulta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public JAgendarConsulta() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Tela Agendar Consulta - GWM");
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_1.setBackground(new Color(178, 187, 182));
		contentPane_1.setBounds(0, 0, 784, 561);
		contentPane.add(contentPane_1);

		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBackground(new Color(21, 23, 43));
		panel_4.setBounds(0, 0, 784, 77);
		contentPane_1.add(panel_4);

		JLabel lblConsultasCriar = new JLabel("Consultas - Agendar");
		lblConsultasCriar.setForeground(Color.WHITE);
		lblConsultasCriar.setFont(new Font("Segoe UI", Font.BOLD, 30));
		lblConsultasCriar.setBounds(471, 14, 285, 41);
		panel_4.add(lblConsultasCriar);

		JLabel lblNewLabel = new JLabel("Clínica GWM");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 19));
		lblNewLabel.setBounds(97, 26, 138, 26);
		panel_4.add(lblNewLabel);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(0, 0, 80, 80);
		panel_4.add(lblNewLabel_3);
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\wesle\\Downloads\\pngtree-medical-health-logo-imag.png"));

		textField = new JTextField();
		textField.setBounds(45, 148, 672, 38);
		contentPane_1.add(textField);
		textField.setColumns(10);

		// Formatter para a data
		try {
			MaskFormatter mfData = new MaskFormatter("##/##/####");
			mfData.setPlaceholderCharacter('_');
			textField_2 = new JFormattedTextField(mfData);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		textField_2.setHorizontalAlignment(SwingConstants.LEFT);
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_2.setBounds(280, 224, 154, 38);
		contentPane_1.add(textField_2);

		comboBoxProfissionalizacoes = new JComboBox<>();
		comboBoxProfissionalizacoes.setFont(new Font("Tahoma", Font.PLAIN, 14));
		comboBoxProfissionalizacoes.setBounds(563, 222, 154, 38);
		contentPane_1.add(comboBoxProfissionalizacoes);

		TextArea textArea = new TextArea();
		textArea.setBounds(45, 305, 672, 176);
		contentPane_1.add(textArea);

		JLabel lblNewLabel_1 = new JLabel("Nome Completo do Paciente");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(45, 123, 196, 14);
		contentPane_1.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Horário");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(45, 199, 46, 14);
		contentPane_1.add(lblNewLabel_2);

		JLabel lblNewLabel_4 = new JLabel("Data");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(280, 199, 63, 14);
		contentPane_1.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Tipo de Consulta");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(563, 197, 154, 14);
		contentPane_1.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("Observações:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(45, 283, 93, 14);
		contentPane_1.add(lblNewLabel_6);

		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveConsulta();
			}
		});

		btnSalvar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSalvar.setForeground(new Color(0, 0, 0));
		btnSalvar.setBackground(new Color(194, 80, 70));
		btnSalvar.setBounds(222, 504, 105, 38);
		contentPane_1.add(btnSalvar);

		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_2.setText("");
				formattedTextField.setText("");
				comboBoxProfissionalizacoes.setSelectedIndex(0);
				textArea.setText("");
				JOptionPane.showMessageDialog(null, "Consulta cancelada.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnCancelar.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnCancelar.setBackground(new Color(85, 121, 143));
		btnCancelar.setBounds(425, 504, 105, 38);
		contentPane.add(btnCancelar);

		try {
			MaskFormatter mfHora = new MaskFormatter("##:##");
			mfHora.setPlaceholderCharacter('_');
			formattedTextField = new JFormattedTextField(mfHora);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		formattedTextField.setHorizontalAlignment(SwingConstants.LEFT);
		formattedTextField.setFont(new Font("Tahoma", Font.PLAIN, 11));
		formattedTextField.setBounds(45, 222, 154, 38);
		contentPane_1.add(formattedTextField);

		// Popula o comboBoxEspecialidades com a lista de especializações dos médicos
		populateProfissionalizacoesComboBox();
	}

	// Método para carregar as especializações dos médicos no comboBox
	private void populateProfissionalizacoesComboBox() {
		List<String> profissionalizacoes = DBConnection.getMedicosProfissionalizacoes();
		for (String profissionalizacao : profissionalizacoes) {
			comboBoxProfissionalizacoes.addItem(profissionalizacao);
		}
	}

	private void saveConsulta() {
		String nome_Paciente = textField.getText();
		String data_Consulta = textField_2.getText();
		String hora_Consulta = formattedTextField.getText();
		String observacoes = new String();
		String profissionalizacao_Medico = (String) comboBoxProfissionalizacoes.getSelectedItem();
		String dataFormatada = formatData(data_Consulta);
		if (dataFormatada == null) {
			JOptionPane.showMessageDialog(null, "Data inválida! Por favor, use o formato DD/MM/YYYY.", "Erro",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		int paciente_Id = DBConnection.findPacienteByName(nome_Paciente);
		int medico_Id = DBConnection.findMedicoByProfissionalizacao(profissionalizacao_Medico);
		if (paciente_Id != -1 && medico_Id != -1) {
			if (DBConnection.saveConsulta(paciente_Id, medico_Id, dataFormatada, hora_Consulta, observacoes,
					profissionalizacao_Medico)) {
				JOptionPane.showMessageDialog(null, "Consulta salva com sucesso!", "Sucesso",
						JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "Erro ao salvar a consulta.", "Erro", JOptionPane.ERROR_MESSAGE);
			}
		} else {
			if (paciente_Id == -1) {
				JOptionPane.showMessageDialog(null, "Paciente não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
			}
			if (medico_Id == -1) {
				JOptionPane.showMessageDialog(null, "Profissionalização do médico não encontrada.", "Erro",
						JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private String formatData(String data) {
		try {
			DateTimeFormatter inputFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate date = LocalDate.parse(data, inputFormat);
			return date.format(outputFormat);
		} catch (DateTimeParseException e) {
			e.printStackTrace();
			return null;
		}
	}
}