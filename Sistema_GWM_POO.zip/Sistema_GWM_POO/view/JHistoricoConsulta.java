package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class JHistoricoConsulta extends JFrame {
	private DefaultTableModel model;
	private JTable tabela;
	private JTextField pesquisaField;

	public JHistoricoConsulta() {
		setTitle("Histórico de Consultas");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		String[] colunas = { "ID", "Nome Paciente", "Data", "Hora", "Profissionalização" };
		model = new DefaultTableModel(colunas, 0);
		tabela = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(tabela);

		pesquisaField = new JTextField(30);
		JButton pesquisarButton = new JButton("Pesquisar");

		pesquisarButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String texto = pesquisaField.getText();
				filtrarDados(texto);
			}
		});

		JPanel searchPanel = new JPanel();
		searchPanel.add(pesquisaField);
		searchPanel.add(pesquisarButton);

		getContentPane().add(scrollPane, BorderLayout.CENTER);
		getContentPane().add(searchPanel, BorderLayout.NORTH);

		carregarDados("");
	}

	private void carregarDados(String filtro) {
		String url = "jdbc:mysql://localhost:3306/sistemamedico";
		String usuario = "root";
		String senha = "root";

		try (Connection conn = DriverManager.getConnection(url, usuario, senha)) {
			String query = "SELECT consultas.id, paciente.nome AS nome_paciente, consultas.data, consultas.hora, consultas.profissionalizacao "
					+ "FROM consultas " + "JOIN paciente ON consultas.paciente_id = paciente.id";

			if (!filtro.isEmpty()) {
				query += " WHERE paciente.nome LIKE ?";
			}

			try (PreparedStatement stmt = conn.prepareStatement(query)) {
				if (!filtro.isEmpty()) {
					stmt.setString(1, "%" + filtro + "%");
				}

				try (ResultSet rs = stmt.executeQuery()) {
					model.setRowCount(0);

					while (rs.next()) {
						int id = rs.getInt("id");
						String nomePaciente = rs.getString("nome_paciente");
						String data = rs.getString("data");
						String hora = rs.getString("hora");
						String profissionalizacao = rs.getString("profissionalizacao");
						model.addRow(new Object[] { id, nomePaciente, data, hora, profissionalizacao });
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void filtrarDados(String filtro) {
		carregarDados(filtro);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			JHistoricoConsulta frame = new JHistoricoConsulta();
			frame.setVisible(true);
		});
	}
}
