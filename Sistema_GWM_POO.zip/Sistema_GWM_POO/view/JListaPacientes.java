package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;
import DAO.DBConnection;

public class JListaPacientes extends JFrame {
	private DefaultTableModel model;
	private JTable tabela;
	private JTextField pesquisaField;
	private TableRowSorter<DefaultTableModel> sorter;

	public JListaPacientes() {
		setTitle("Listar Pacientes");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		String[] colunas = { "Matricula", "CPF", "Nome", "Genero", "Data de Nascimento" };
		model = new DefaultTableModel(colunas, 0);
		tabela = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(tabela);

		sorter = new TableRowSorter<>(model);
		tabela.setRowSorter(sorter);

		pesquisaField = new JTextField(30);
		pesquisaField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String texto = pesquisaField.getText().toLowerCase();
				if (texto.trim().length() == 0) {
					sorter.setRowFilter(null);
				} else {
					sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto));
				}
			}
		});

		JPanel searchPanel = new JPanel();
		searchPanel.add(new JLabel("Pesquisar:"));
		searchPanel.add(pesquisaField);

		add(scrollPane, BorderLayout.CENTER);
		add(searchPanel, BorderLayout.NORTH);

		carregarDados();
	}

	private void carregarDados() {
		String url = "jdbc:mysql://localhost:3306/sistemamedico";
		String usuario = "root";
		String senha = "root";

		try (Connection conn = DriverManager.getConnection(url, usuario, senha)) {
			String query = "SELECT id, cpf, nome, genero, dataNasc FROM Paciente";

			try (PreparedStatement stmt = conn.prepareStatement(query)) {
				try (ResultSet rs = stmt.executeQuery()) {
					model.setRowCount(0);

					while (rs.next()) {
						int id = rs.getInt("id");
						String cpf = rs.getString("cpf");
						String nome = rs.getString("nome");
						String genero = rs.getString("genero");
						String dataNasc = rs.getString("dataNasc");
						model.addRow(new Object[] { id, cpf, nome, genero, dataNasc });
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			JListaPacientes frame = new JListaPacientes();
			frame.setVisible(true);
		});
	}
}
