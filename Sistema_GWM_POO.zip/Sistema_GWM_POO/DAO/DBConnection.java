package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DBConnection {

	private static Connection connection = null;

	private static final String URL = "jdbc:mysql://localhost:3306/sistemamedico";
	private static final String USER = "root";
	private static final String PASSWORD = "root";

	private DBConnection() {
	}

	public static Connection getConnection() throws SQLException {
		if (connection == null || connection.isClosed()) {
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
		}
		return connection;
	}

	public static void closeConnection() {
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
				connection = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método auxiliar para formatar a data
	private static String formatDate(String dataNasc) {
		try {
			SimpleDateFormat originalFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date date = originalFormat.parse(dataNasc);
			SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
			return targetFormat.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static boolean savePatient(String nome, String dataNasc, String cpf, String genero, String email,
			String telefone, String cep, String logradouro, String bairro, String cidade, String uf) {
		String sql = "INSERT INTO paciente (nome, dataNasc, cpf, genero, email, telefone, cep, logradouro, bairro, cidade, uf) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

			stmt.setString(1, nome);
			stmt.setString(2, formatDate(dataNasc));
			stmt.setString(3, cpf);
			stmt.setString(4, genero);
			stmt.setString(5, email);
			stmt.setString(6, telefone);
			stmt.setString(7, cep);
			stmt.setString(8, logradouro);
			stmt.setString(9, bairro);
			stmt.setString(10, cidade);
			stmt.setString(11, uf);

			int rowsAffected = stmt.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public static boolean findPatientByName(String nome) {
		String sql = "SELECT * FROM paciente WHERE nome = ?";

		try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

			stmt.setString(1, nome);
			ResultSet rs = stmt.executeQuery();
			return rs.next();

		} catch (SQLException e) {

			e.printStackTrace();
			return false;

		}

	}

	public static boolean verificaLogin(String usuario, String senha) {
		String sql = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";

		try (Connection conn = getConnection();

				PreparedStatement stmt = conn.prepareStatement(sql)) {

			stmt.setString(1, usuario);
			stmt.setString(2, senha);
			ResultSet rs = stmt.executeQuery();

			return rs.next(); // Retorna true se as credenciais são válidas

		} catch (SQLException e) {

			e.printStackTrace();

			return false;
		}
	}

	public static boolean savePatient1(String nome, String dataNasc, String cpf, String genero, String email,
			String telefone, String cep, String logradouro, String bairro, String cidade, String uf,
			String profissionalizacao, String matricula) {

		String query = "INSERT INTO medicos (nome, data_nasc, cpf, genero, email, telefone, cep, logradouro, bairro, cidade, uf, profissionalizacao, matricula) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = getConnection();

				PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setString(1, nome);
			stmt.setString(2, formatDate(dataNasc));
			stmt.setString(3, cpf);
			stmt.setString(4, genero);
			stmt.setString(5, email);
			stmt.setString(6, telefone);
			stmt.setString(7, cep);
			stmt.setString(8, logradouro);
			stmt.setString(9, bairro);
			stmt.setString(10, cidade);
			stmt.setString(11, uf);
			stmt.setString(12, profissionalizacao);
			stmt.setString(13, matricula);

			int rowsAffected = stmt.executeUpdate();

			return rowsAffected > 0;

		} catch (SQLException e) {

			e.printStackTrace();

			return false;
		}
	}

	public static int findPacienteByName(String nome) {
		try (Connection conn = getConnection();
				PreparedStatement stmt = conn.prepareStatement("SELECT id FROM paciente WHERE nome = ?")) {
			stmt.setString(1, nome);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return rs.getInt("id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

	public static int findMedicoByProfissionalizacao(String profissionalizacao) {
		try (Connection conn = getConnection();
				PreparedStatement stmt = conn.prepareStatement("SELECT id FROM medicos WHERE profissionalizacao = ?")) {
			stmt.setString(1, profissionalizacao);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return rs.getInt("id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

	public static boolean saveConsulta(int pacienteId, int medicoId, String data, String hora, String observacoes,
			String profissionalizacao) {
		try (Connection conn = getConnection();
				PreparedStatement stmt = conn.prepareStatement(
						"INSERT INTO consultas (paciente_id, medico_id, data, hora, observacoes, profissionalizacao) VALUES (?, ?, ?, ?, ?, ?)")) {
			stmt.setInt(1, pacienteId);
			stmt.setInt(2, medicoId);
			stmt.setString(3, data);
			stmt.setString(4, hora);
			stmt.setString(5, observacoes);
			stmt.setString(6, profissionalizacao);
			int rowsAffected = stmt.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static List<String> getMedicosProfissionalizacoes() {
		List<String> profissionalizacoes = new ArrayList<>();
		try (Connection conn = getConnection();
				PreparedStatement stmt = conn.prepareStatement("SELECT DISTINCT profissionalizacao FROM medicos")) {
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				profissionalizacoes.add(rs.getString("profissionalizacao"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return profissionalizacoes;
	}
}